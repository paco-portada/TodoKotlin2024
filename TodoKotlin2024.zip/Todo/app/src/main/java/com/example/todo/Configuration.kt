package com.example.todo

class Configuration {
    companion object {
        const val BASE_URL = "https://laravel.alumno.me/"
    }
}
