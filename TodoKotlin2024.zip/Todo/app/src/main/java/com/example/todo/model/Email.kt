package com.example.todo.model

class Email(var to: String, var from: String, var subject: String, var message: String)