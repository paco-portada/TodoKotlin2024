Aplicación en Kotlin que se comunica con el API REST en https://laravel.alumno.me

Cambiar en el fichero Configuracion.kt la URL con el dominio propio.

![Captura de pantalla](Screenshot.png)

![Captura de pantalla](Screenshot_panel.png)

